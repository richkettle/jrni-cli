#!/usr/bin/env node

const bundle = require('./bundle');
const zip = require('./zip');

console.log('Started webpack bundle');
bundle(function (err) {
    if (err) throw err;
    console.log('Completed webpack bundle');
    console.log('Started zip');
    zip(function (err) {
        if (err) throw err;
        console.log('Completed zip');
    });
});
