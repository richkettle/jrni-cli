const fs = require('fs');
const archiver = require('archiver');

const output = fs.createWriteStream('app.zip');
const archive = archiver('zip');

function zip(cb) {
    console.log('-0-----------------------------');
    const dir = process.cwd();
    console.log(process.cwd());
    process.chdir('..');
    console.log(process.cwd());
    console.log('dir');
    console.log(dir);
    output.on('close', function () {
        console.log(archive.pointer() + ' total bytes');
        console.log('archiver has been finalized and the output file descriptor has closed.');
        cb();
    });
    archive.on('warning', function (err) {
        if (err.code === 'ENOENT') {
            console.warn(err.message);
        } else {
            cb(err);
        }
    });
    archive.on('error', function (err){
        cb(err);
    });
    archive.pipe(output);
    archive.directory(dir, dir);
    archive.finalize();
}

module.exports = zip;
